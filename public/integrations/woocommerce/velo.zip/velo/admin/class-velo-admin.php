<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://veloapp.io
 * @since      1.0.0
 *
 * @package    Velo
 * @subpackage Velo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Velo
 * @subpackage Velo/admin
 * @author     Velo <itay@veloapp.io>
 */
class Velo_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->load_dependencies();

	}

	/**
 * Load the required dependencies for the Admin facing functionality.
 *
 * Include the following files that make up the plugin:
 *
 * - Wppb_Demo_Plugin_Admin_Settings. Registers the admin settings and page.
 *
 *
 * @since    1.0.0
 * @access   private
 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) .  'admin/class-velo-settings.php';

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Velo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Velo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/velo-admin.css', [], /*$this->version*/ time(), 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Velo_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Velo_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/velo-admin.js', array( 'jquery' ), $this->version, false );

		/**
		 * Adds a "Send to Velo" btn
		 * to the orders table's bulk actions menu
		 */
	}

	public function registerVeloBulkAction ($bulk_actions) {
		$bulk_actions['veloappio_send_order_to_velo'] = __('send_order_to_velo', 'veloappio');
		return $bulk_actions;
	}

	public function handleVeloBulkAction ($redirect_to, $do_action, $post_ids) {
		if ($do_action !== 'veloappio_send_order_to_velo' || !count($post_ids)) {
			return $redirect_to;
		}

		$api = new Velo_Api();
		$result = $api->export_deliveries($post_ids, true);
		if (is_wp_error($result)) {
			return $result;
		}

		if (!strlen($result)) {
			return $redirect_to;
		}

		return $result;
	}

	public function registerVeloActionsColumn ($columns) {
		if (is_array($columns)) {
			$columns['veloappio_actions'] = esc_html(__('veloappio_actions', 'veloappio'));
		}
		return $columns;
	}

	public function renderVeloActionsColumn ($column, $post_id) {
			$api = new Velo_Api();
			if ($column !== 'veloappio_actions') {
				return;
			}

			$order = wc_get_order($post_id);

			$markup = '<p class="wc_actions column-wc_actions">';
			$orderName = $order->get_meta('veloappio_order_name');
			if ($orderName && strlen($orderName)) {
				$title = __('print_sticker', 'veloappio');
				$markup .= '<div ';
					$markup .= 'class="button wc-action-button veloappio-actions-column-btn" ';
					$markup .= 'data-velo-target="'.rtrim($api->server_root, '/').'/sticker/'.$orderName.'" ';
					$markup .= 'aria-label="'.$title.'"';
				$markup .= '>';
				$markup .= '<img class="veloappio-action-column-btn-img veloappio-not-loading-img" src="'.rtrim(plugin_dir_url(__DIR__), '/').'/images/velo.svg">';
				$markup .= '<img class="veloappio-action-column-btn-img veloappio-loading-img" src="'.rtrim(plugin_dir_url(__DIR__), '/').'/images/spinner.svg">';
				$markup .= '</div>';
			} else {
				$title = __('send_order_to_velo', 'veloappio');
				$markup .= '<div ';
					$markup .= 'class="button wc-action-button veloappio-actions-column-btn" ';
					$markup .= 'data-velo-target="'.admin_url('admin-ajax.php?action=send_to_velo&post_id='. $order->get_id()).'" ';
					$markup .= 'title="'.$title.'" ';
					$markup .= 'aria-label="'.$title.'"';
				$markup .= '>';
					$markup .= '<img class="veloappio-action-column-btn-img veloappio-not-loading-img" src="'.rtrim(plugin_dir_url(__DIR__), '/').'/images/velo.svg">';
					$markup .= '<img class="veloappio-action-column-btn-img veloappio-loading-img" src="'.rtrim(plugin_dir_url(__DIR__), '/').'/images/spinner.svg">';
				$markup .= '</div>';
			}

			$markup .= '</p>';

			echo $markup;
	}

	public function handleVeloActionsColumnSendToVelo () {
		$post_id = isset($_GET['post_id']) ? sanitize_text_field($_GET['post_id']) : null;
		$redirectTo = admin_url('edit.php?post_type=shop_order');

		if (!$post_id) {
			wp_redirect($redirectTo);
			exit;
		}

		$api = new Velo_Api();
 		print_r($api->export_deliveries([$post_id]));
		exit;
	}
}
