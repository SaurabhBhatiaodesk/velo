<?php

/**
 * The settings of the plugin.
 *
 * @link       https://veloapp.io
 * @since      1.0.0
 *
 * @package    Velo
 * @subpackage Velo/admin
 */

/**
 * Class WordPress_Plugin_Template_Settings
 *
 */
class Velo_Settings
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct($plugin_name, $version)
	{

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * This function introduces the theme options into the 'Appearance' menu and into a top-level
	 * 'Velo' menu.
	 */
	public function setup_plugin_options_menu()
	{

		//Add the menu to the Plugins set of menu items
		add_plugins_page(
			'Velo Settings', 					// The title to be displayed in the browser window for this page.
			'Velo Settings',					// The text to be displayed for this menu item
			'manage_options',					// Which type of users can see this menu item
			'woocommerce_veloappio_shipping_method_settings',			// The unique ID - that is, the slug - for this menu item
			[$this, 'render_settings_page_content']				// The name of the function to call when rendering this menu's page
		);

	}

	/**
	 * Provides default values for the Display Options.
	 *
	 * @return array
	 */
	public function default_veloappio_settings()
	{
		$defaults = array(
			'api_key' => '',
			'api_secret' => '',
		);

		return $defaults;
	}

	/**
	 * Renders a simple page to display for the theme menu defined above.
	 */
	public function render_settings_page_content()
	{
		?>
		<!-- Create a header in the default WordPress 'wrap' container -->
		<div class="wrap">

			<h2><?php _e('velo_settings_title', 'veloappio'); ?></h2>
			<?php settings_errors(); ?>

			<form method="post" action="options.php">
				<?php

				$this->initialize_veloappio_settings();
				settings_fields('woocommerce_veloappio_shipping_method_settings');
				do_settings_sections('woocommerce_veloappio_shipping_method_settings');
				submit_button();

				?>
			</form>

		</div><!-- /.wrap -->
		<?php
	}

	/**
	 * This function provides a simple description for the General Options page.
	 *
	 * It's called from the 'wppb-demo_initialize_theme_options' function by being passed as a parameter
	 * in the add_settings_section function.
	 */
	public function general_options_callback()
	{
		echo '<p>' . __('admin_settings_title', 'veloappio') . '</p>';
	} // end general_options_callback

	/**
	 * Initializes the theme's display options page by registering the Sections,
	 * Fields, and Settings.
	 *
	 * This function is registered with the 'admin_init' hook.
	 */
	public function initialize_veloappio_settings()
	{

		// If the theme options don't exist, create them.
		if (false == get_option('woocommerce_veloappio_shipping_method_settings')) {
			$default_array = $this->default_veloappio_settings();
			add_option('woocommerce_veloappio_shipping_method_settings', $default_array);
		}


		add_settings_section(
			'general_settings_section',			          // ID used to identify this section and with which to register options
			__('settings_section_title', 'veloappio'),// Title to be displayed on the administration page
			array($this, 'general_options_callback'),// Callback used to render the description of the section
			'woocommerce_veloappio_shipping_method_settings'		                  // Page on which to add this section of options
		);

		// Next, we'll introduce the fields for setting the api key and secret
		add_settings_field(
			'api_key',											      	  // ID used to identify the field throughout the theme
			__('api_key_input', 'veloappio'),					// The label to the left of the option interface element
			[$this, 'api_key_callback'],							// The name of the function responsible for rendering the option interface
			'woocommerce_veloappio_shipping_method_settings',	           			 		// The page on which this option will be displayed
			'general_settings_section',			        	// The name of the section to which this field belongs
			[__('api_key_description', 'veloappio')], // The array of arguments to pass to the callback. In this case, just a description.
		);

		add_settings_field(
			'api_secret',
			__('api_secret_input', 'veloappio'),
			[$this, 'api_secret_callback'],
			'woocommerce_veloappio_shipping_method_settings',
			'general_settings_section',
			[__('api_secret_description', 'veloappio')],
		);

		add_settings_field(
			'email',
			__('email_input', 'veloappio'),
			[$this, 'email_callback'],
			'woocommerce_veloappio_shipping_method_settings',
			'general_settings_section',
			[__('email_input_description', 'veloappio')],
		);

		add_settings_field(
			'password',
			__('password_input', 'veloappio'),
			[$this, 'password_callback'],
			'woocommerce_veloappio_shipping_method_settings',
			'general_settings_section',
			[__('password_input_description', 'veloappio')],
		);

		// Finally, we register the fields with WordPress
		register_setting(
			'woocommerce_veloappio_shipping_method_settings',
			'woocommerce_veloappio_shipping_method_settings'
		);

	} // end veloappio_initialize_theme_options

	/**
	 * These functions render the interface elements for the settings
	 *
	 * They accept an array or arguments and expects the first element in the array to be the description
	 * to be displayed next to the input.
	 */
	public function api_key_callback($args)
	{

		// First, we read the options collection
		$options = get_option('woocommerce_veloappio_shipping_method_settings');

		// Next, we update the name attribute to access this element's ID in the context of the display options array
		// We also access the api_key element of the options collection in the call to the checked() helper function
		$html = '<input type="text" id="api_key" name="veloappio_settings[api_key]" value="' . (isset($options['api_key']) ? $options['api_key'] : '') . '" />';

		// Here, we'll take the first argument of the array and add it to a label next to the checkbox
		$html .= '<br /><label for="api_key">&nbsp;' . $args[0] . '</label>';

		echo $html;

	} // end api_key_callback

	public function api_secret_callback($args)
	{

		// First, we read the options collection
		$options = get_option('woocommerce_veloappio_shipping_method_settings');

		// Next, we update the name attribute to access this element's ID in the context of the display options array
		// We also access the api_secret element of the options collection in the call to the checked() helper function
		$html = '<input type="password" id="api_secret" name="veloappio_settings[api_secret]" value="' . (isset($options['api_secret']) ? $options['api_secret'] : '') . '" />';

		// Here, we'll take the first argument of the array and add it to a label next to the checkbox
		$html .= '<br /><label for="api_secret">&nbsp;' . $args[0] . '</label>';

		echo $html;

	} // end api_secret_callback

	public function email_callback($args)
	{

		// First, we read the options collection
		$options = get_option('woocommerce_veloappio_shipping_method_settings');

		// Next, we update the name attribute to access this element's ID in the context of the display options array
		// We also access the email element of the options collection in the call to the checked() helper function
		$html = '<input type="text" id="email" name="veloappio_settings[email]" value="' . (isset($options['email']) ? $options['email'] : '') . '" />';

		// Here, we'll take the first argument of the array and add it to a label next to the checkbox
		$html .= '<br /><label for="email">&nbsp;' . $args[0] . '</label>';

		echo $html;

	} // end email_callback

	public function password_callback($args)
	{

		// First, we read the options collection
		$options = get_option('woocommerce_veloappio_shipping_method_settings');

		// Next, we update the name attribute to access this element's ID in the context of the display options array
		// We also access the password element of the options collection in the call to the checked() helper function
		$html = '<input type="password" id="password" name="veloappio_settings[password]" value="' . (isset($options['password']) ? $options['password'] : '') . '" />';

		// Here, we'll take the first argument of the array and add it to a label next to the checkbox
		$html .= '<br /><label for="password">&nbsp;' . $args[0] . '</label>';

		echo $html;

	} // end password_callback
}
