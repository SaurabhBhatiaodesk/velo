(function($) {
	'use strict';

	function veloappio_toast (msg, toastType) {
		let $toast = '';
		$toast +=	'<div class="veloappio-toast veloappio-toast-' + toastType + '">';
			$toast += '<p>' + msg + '</p>';
			$toast +=	'<button type="button" ';
				$toast +=	'class="notice-dismiss" ';
				$toast +=	'onclick="this.parentNode.classList.remove(\'veloappio-toast-active\');">';
				$toast +=	'</button>';
		$toast += '</div>';
		$toast = $($toast);
		$('#wpwrap').prepend($toast);
		setTimeout(() => {
			$toast.addClass('veloappio-toast-active');
			setTimeout(() => {
				$toast.removeClass('veloappio-toast-active');
				setTimeout(() => {
					$toast.remove();
				}, 300);
			}, 5000);
		}, 50);
	}

	 $(() => {
		 $('.veloappio-actions-column-btn').click(function (e) {
			 e.stopPropagation();
			 const $btn = $(this);
			 $btn.addClass('veloappio-loading');
			 $.get($(this).data('velo-target')).then(res => {
				 res = JSON.parse(res);
				 veloappio_toast(res.message, res.success ? 'success' : 'error');
				 $btn.removeClass('veloappio-loading');
			 }).catch(e => {
				 console.log({ e });
				 $btn.removeClass('veloappio-loading');
			 })
		 })
	 });
})(jQuery);


function veloappio_dismiss_notification(el) {
  jQuery(el).parent().slideUp('normal', function() {
		jQuery(this).remove();
	});
  return false;
}
