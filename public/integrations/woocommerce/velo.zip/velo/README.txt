=== Plugin Name ===
Contributors: veloitay
Donate link: https://veloapp.io
Tags: deliveries, shipping, velo
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

the Velo app's official plugin. https://veloapp.io

== Description ==

Velo simplifies the store-to-door delivery process for retailers by integrating with multiple store locations and assigning orders to the nearest store for local delivery. The app integrates with multiple store locations, manages live inventory, improves order management, pickup efficiency, shows detailed tracking information, and orders history.

== Installation ==
1. Upload the plugin's zip file via the 'Plugins' page in wordpress admin.
2. Activate the plugin through the 'Plugins' page in WordPress admin.
3. Input your Velo credentials in the 'Velo settings' page, which can be found in the 'Plugins' menu in Wordpress.
4. Add and activate 'Velo Shipping' in your shipping zones settings (WooCommerce->Settings->Shipping Settings)
5. Velo delivery options will now appear in checkout for all relevant customers.
