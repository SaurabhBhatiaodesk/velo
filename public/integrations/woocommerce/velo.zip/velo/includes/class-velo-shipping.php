<?php
/*
Plugin Name: Velo Shipping plugin
Plugin URI: https://veloapp.io
Description: Velo shipping method plugin
Version: 1.0.0
Author: Velo
Author URI: https://veloapp.io
*/

/**
 * Check if WooCommerce is active
 */

if (!defined('WPINC')) {
  die;
}
/*
 * Check if WooCommerce is active
 */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
  function velo_shipping_method()
  {
    if (!class_exists('Velo_shipping_method')) {
      class Velo_shipping_method extends WC_Shipping_Method
      {
        /**
         * Constructor for your shipping class
         *
         * @access public
         * @return void
         */
        public $triggered = false;
        public function __construct($instance_id = 0)
        {
          $this->id = 'veloappio_shipping_method';
          $this->enabled = 'yes';
          $this->instance_id = absint($instance_id);
          $this->method_title = __('method_title', 'veloappio');  // Title shown in admin
          $this->method_description = __('method_description', 'veloappio'); // Description shown in admin
          $this->title = __('method_title', 'veloappio');
          $this->supports = ['settings', 'shipping-zones'];

          $this->init_form_fields();
          $this->init_instance_settings();
          $this->init_settings();

          add_action('woocommerce_update_options_shipping_' . $this->id, [$this, 'process_admin_options']);

        }

        /**
         * Method init_form_fields
         *
         * @return void
         */
        public function init_form_fields()
        {
          $this->form_fields = array(
            'api_key' => array(
              'title' => __('API Key', 'woocommerce'),
              'type' => 'text',
              'description' => __('Your Velo Wordpress API Key', 'woocommerce'),
              'desc_tip' => true,
            ),
            'api_secret' => array(
              'title' => __('API Secret', 'woocommerce'),
              'type' => 'password',
              'description' => __(' Your Velo Wordpress API Secret.', 'woocommerce'),
              'desc_tip' => true,
            ),
            'email' => array(
              'title' => __('Velo Email', 'woocommerce'),
              'type' => 'text',
              'description' => __(' The email address you use to log into the Velo app.', 'woocommerce'),
              'desc_tip' => true,
            ),
            'password' => array(
              'title' => __('Velo Password', 'woocommerce'),
              'type' => 'password',
              'description' => __('  Your Password for the Velo App.', 'woocommerce'),
              'desc_tip' => true,
            ),
          );
        }

        /**
         * This function is used to calculate the shipping cost.
         * Within this function we can check for weights, dimensions and other parameters.
         *
         * @access public
         * @param mixed $package
         * @return void
         */
        public function calculate_shipping($package = [])
        {
          if ($this->triggered) {
            return;
          }

          $address = parseAddressFromPostRequest();

          $error = false;
          foreach (['first_name', 'line1', 'city', 'country', 'phone'] as $required) {
            if (empty($address[$required])) {
              $error = true;
            }
          }

          if (!$error) {
            $api = new Velo_Api();
            $weight = 0;
            $products = [];
            foreach ($package['contents'] as $item_id => $item) {
              $variation = '';
              if (isset($item['variation_id']) && !!$item['variation_id']) {
                $variation = wc_get_product($item['variation_id'])->get_formatted_name();
              }
              $weight += floatVal($item['data']->get_weight()) * $item['quantity'];

              $products[] = [
                'name' => $item['data']->get_title(),
                'variation' => $variation,
                'code' => $item['data']->get_sku(),
                'price' => $item['data']->get_price(),
                'quantity' => $item['quantity'],
              ];
            }
            $weight = wc_get_weight($weight, 'kg');
            $sessionRatesExists = WC()->session->get('veloappio_shipping_rates_calculated');
            if ($sessionRatesExists === format_address_string($address)) {
              return;
            }
            // $ratesResponse = array();
            $ratesResponse = $api->get_shipping_options($address, $weight, $products);

            if (is_wp_error($ratesResponse) || empty($ratesResponse)) {
              $this->add_rate(array());
              WC()->session->set($this->id . '_rates', array());
              add_filter('woocommerce_package_rates', function () {
                return array();
              });
              return;
            }
            $rates = [];
            if (count($ratesResponse)) {
              foreach ($ratesResponse as $option) {
                $optionId = $this->id . '_POL_' . $option['polygon_id'];
                if (!empty($option['external_service_id'])) {
                  $optionId .= '_EXT_'.$option['external_service_id'];
                }
                $option = [
                  'id' => $optionId,
                  'label' => isset($option['service_name']) ? $option['service_name'] : '',
                  'cost' => strval($option['rate']['price']),
                  'taxes' => array(),
                  'meta_data' => [
                    'description' => isset($option['description']) ? $option['description'] : '',
                    'shipping_code' => $option['shipping_code']['code'],
                  ],
                ];
                $rates[] = $option;
                $this->add_rate($option);
              }

              if (!empty($rates)) {
                WC()->session->set('veloappio_shipping_rates_calculated', format_address_string($address));
              }
              WC()->session->set($this->id . '_rates', $rates);
              $this->triggered = true;
            }
          }
        }
      }
    }
  }
  add_action('woocommerce_shipping_init', 'velo_shipping_method');
  add_filter('woocommerce_debug_mode', '__return_true');

  function veloappio_checkout_field_process()
  {
    $address = parseAddressFromPostRequest();
    $sessionRatesExists = WC()->session->get('veloappio_shipping_rates_calculated');
    if ($sessionRatesExists === format_address_string($address)) {
      return;
    }

    static $processing = false;

    if ($processing) {
      return;
    }

    $processing = true;

    // Ensure the cart object is available
    if (WC()->cart) {
      // Calculate shipping and totals
      WC()->cart->calculate_totals();
      WC()->cart->calculate_shipping();
    }

    $processing = false;
  }
  add_action('woocommerce_checkout_update_order_review', 'veloappio_checkout_field_process', 10);


  function add_velo_shipping_method($methods)
  {
    $methods['veloappio_shipping_method'] = 'Velo_shipping_method';
    return $methods;
  }
  add_filter('woocommerce_shipping_methods', 'add_velo_shipping_method');

  function reset_default_shipping_method($method, $available_methods)
  {
    if (!empty($method)) {
      return $method;
    }

    if (!is_array($available_methods)) {
      return $method;
    }

    foreach ($available_methods as $method_id => $method_obj) {
      if ($method_obj->method_id === 'veloappio_shipping_method') {
        return $method_id;
      }
    }
    // If the shipping method has been chosen don't do anything

    // find way to dd
    // set default
    // $rates = WC()->session->get('veloappio_shipping_method_rates');
    // if ($rates && count($rates)) {
    // 	return $rates[array_key_first($rates)]['id'];
    // }

    return $method;
  }

  add_filter('woocommerce_shipping_chosen_method', 'reset_default_shipping_method', 10, 2);

  function add_velo_shipping_rates($package_rates, $package)
  {
    $chosen_shipping_methods = WC()->session->get('chosen_shipping_methods');
    $is_local_pickup = false;
    if (is_array($chosen_shipping_methods) && in_array('local_pickup', $chosen_shipping_methods)) {
      $is_local_pickup = true;
    }

    $stored_rates = WC()->session->get('veloappio_shipping_method_rates');

    if (!empty($stored_rates)) {
      foreach ($stored_rates as $rate) {
        if ($is_local_pickup && strpos($rate['label'], 'velo') !== false) {
          continue;
        }

        $rate_obj = new WC_Shipping_Rate(
          $rate['id'],
          $rate['label'],
          $rate['cost'],
          array(),
          'veloappio_shipping_method'
        );
        $package_rates[$rate['id']] = $rate_obj;
      }
    }

    uasort($package_rates, function ($a, $b) {
      $a_is_velo = strpos($a->id, 'veloappio_shipping_method') === 0;
      $b_is_velo = strpos($b->id, 'veloappio_shipping_method') === 0;

      if ($a_is_velo && !$b_is_velo) {
        return -1;
      } elseif (!$a_is_velo && $b_is_velo) {
        return 1;
      } else {
        return 0;
      }
    });

    return $package_rates;
  }

  add_filter('woocommerce_package_rates', 'add_velo_shipping_rates', 30, 2);

  function veloappio_send_order_to_api($order_id, $posted_data, $order)
  {
    if (
      isset($posted_data['shipping_method']) &&
      isset($posted_data['shipping_method'][0]) &&
      strlen($posted_data['shipping_method'][0]) &&
      strpos($posted_data['shipping_method'][0], 'veloappio_shipping_method_POL_') !== false
    ) {
      $polygonId = explode('_POL_', $posted_data['shipping_method'][0]);
      $polygonId = end($polygonId);
      $externalServiceId = false;
      if (strpos($polygonId, '_EXT_') !== false) {
        $externalServiceId = explode('_EXT_', $polygonId);
        $externalServiceId = intVal(end($externalServiceId));
        $polygonId = explode('_EXT_', $polygonId)[0];
      }
      $polygonId = intVal($polygonId);

      $api = new Velo_Api();

      $api->send_order($order, $polygonId, $externalServiceId);
    }
    // WC()->session->set('veloappio_shipping_rates_calculated', false);
    // WC()->session->__unset('veloappio_shipping_rates_calculated');
  }
  add_action('woocommerce_checkout_order_processed', 'veloappio_send_order_to_api', 10, 3);

  function veloappio_update_shipping_options_when_relevant_input_changes()
  {
    if (is_checkout()) {
      ?>
      <script type="text/javascript">
        /* global wc_checkout_params */
        // wc_checkout_params is required to continue, ensure the object exists
        jQuery(function ($) {

          let debounce = null;
          const veloappioTriggerShippingMethodsUpdate = () => {
            clearTimeout(debounce);
            debounce = setTimeout(function () {
              // make sure the shipping method is updated every time
              // wc_checkout_params.update_shipping_method = true;
              //
              var billing_country = jQuery('#billing_country').val();
              var billing_postcode = jQuery('#billing_postcode').val();
              var billing_city = jQuery('#billing_city').val();
              var billing_address_1 = jQuery('#billing_address_1').val();

              if (billing_country != '' && billing_postcode != '' && billing_city != '' && billing_address_1 != '') {
                $(document.body).trigger('update_checkout');
              }

              // console.log('updating checkout');
            }, 1000);
          };

          const inputsToTrigger = [
            // '#billing_first_name',
            // '#shipping_first_name',
            // '#billing_last_name',
            // '#shipping_last_name',
            '#billing_country',
            '#billing_postcode',
            '#billing_city',
            '#billing_address_1',
            // '#billing_house_number',
            // '#billing_phone',
            // '#billing_email',
            '#shipping_country',
            '#shipping_postcode',
            '#shipping_city',
            '#shipping_address_1',
            // '#shipping_phone',
            // '#shipping_house_number',
          ];

          // $(inputsToTrigger.join(', ')).on('change input', veloappioTriggerShippingMethodsUpdate);
          // $('body').on('init_checkout', veloappioTriggerShippingMethodsUpdate);

          // 	jQuery(document.body).on('input click', function() {
          // 		jQuery(document.body).trigger('update_checkout');
          // 	});

          // jQuery('body').on('updated_checkout', function () {
          // 	// if( !$('.shipping_method').length ){
          // 	//     alert('No Shipping method available');
          // 	//     // popup code
          // 	// }
          // });
        });
      </script>
      <?php
    }
  }
  add_action('wp_footer', 'veloappio_update_shipping_options_when_relevant_input_changes', 50);
}

function format_address_string(array $address)
{
  $array = array_values(array_filter($address));
  return str_replace(' ', '', implode('', $address));
}

function parseAddressFromPostRequest()
{
  $postData = $_POST;
  if (isset($_POST['post_data'])) {
    $postData = [];
    parse_str($_POST['post_data'], $postData);
  }
  $address = [
    'first_name' => null,
    'last_name' => null,
    'phone' => null,
    'line1' => null,
    'line2' => (isset($_POST['s_address_2'])) ? $_POST['s_address_2'] : '',
    'city' => (isset($_POST['s_city'])) ? $_POST['s_city'] : '',
    'state' => (isset($_POST['s_state'])) ? $_POST['s_state'] : '',
    'zipcode' => (isset($_POST['s_postcode'])) ? $_POST['s_postcode'] : '',
    'country' => (isset($_POST['s_country'])) ? WC()->countries->countries[$_POST['s_country']] : 'Israel',
  ];

  if (isset($_POST['s_address'])) {
    $address['line1'] = $_POST['s_address'];
  } else if (isset($_POST['s_address_1'])) {
    $address['line1'] = $_POST['s_address_1'];
  }

  foreach (['s_', ''] as $addressPrefix) {
    $postData[$addressPrefix . 'line1'] = '';
    if (isset($postData[$addressPrefix . 'address'])) {
      $postData[$addressPrefix . 'line1'] = $postData[$addressPrefix . 'address'];
      unset($postData[$addressPrefix . 'address']);
    } else if (isset($postData[$addressPrefix . 'address_1'])) {
      $postData[$addressPrefix . 'line1'] = $postData[$addressPrefix . 'address_1'];
      unset($postData[$addressPrefix . 'address_1']);
    }

    if (isset($postData[$addressPrefix . 'address_2'])) {
      $postData[$addressPrefix . 'line2'] = $postData[$addressPrefix . 'address_2'];
      unset($postData[$addressPrefix . 'address_2']);
    }

    if (isset($postData[$addressPrefix . 'postcode'])) {
      $postData[$addressPrefix . 'zipcode'] = $postData[$addressPrefix . 'postcode'];
      unset($postData[$addressPrefix . 'postcode']);
    }

    if (isset($postData[$addressPrefix . 'country'])) {
      $postData[$addressPrefix . 'country'] = WC()->countries->countries[$postData[$addressPrefix . 'country']];
    }
  }

  foreach ($address as $input => $value) {
    if (is_null($address[$input]) || !strlen($address[$input])) {
      if (isset($postData['billing_' . $input]) && !is_null($postData['billing_' . $input]) && strlen($postData['billing_' . $input])) {
        $address[$input] = $postData['billing_' . $input];
      } else if (isset($postData['shipping_' . $input]) && !is_null($postData['shipping_' . $input]) && strlen($postData['shipping_' . $input])) {
        $address[$input] = $postData['shipping_' . $input];
      }
    }
  }

  return $address;
}

// add_action('woocommerce_before_checkout_form', 'wc_force_shipping_on_checkout_load');
// function wc_force_shipping_on_checkout_load() {
//     WC()->cart->calculate_shipping();
// }

// add_action('init', 'clear_woocommerce_cart_session');
// function clear_woocommerce_cart_session() {
// 	// WC()->cart->empty_cart();
// 	WC()->session->destroy_session();
// }
