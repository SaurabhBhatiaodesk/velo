<?php

/**
 * API
 *
 * This class handles communication between Velo API and wp
 *
 * @since      1.0.0
 * @package    Velo
 * @subpackage Velo/includes
 * @author     Velo <itay@veloapp.io>
 */
class Velo_Api
{
  // private $server_root = 'https://accepted-mule-alive.ngrok-free.app';
  private $server_root = 'https://api.veloapp.io';
  private $settings = [];

  public function __construct()
  {
    $this->settings = get_option('woocommerce_veloappio_shipping_method_settings');
  }

  private function parse_wp_remote_response($response)
  {
    return [
      'code' => wp_remote_retrieve_response_code($response),
      'body' => json_decode(wp_remote_retrieve_body($response), true),
    ];
  }

  private function api_endpoint($path)
  {
    return rtrim($this->server_root, '/') . '/api/woocommerce/' . $path;
  }

  private function api_request($endpoint, $options = [], $retry = false)
  {
    if (!str_starts_with($endpoint, $this->server_root)) {
      $endpoint = $this->api_endpoint($endpoint);
    }
    $response = $this->parse_wp_remote_response(wp_remote_post($endpoint, $options));

    if (defined('WP_DEBUG') && WP_DEBUG) {
      error_log('Velo api request ' . json_encode([
        'endpoint' => $endpoint,
        'options' => $options,
        'response' => $response,
      ], TRUE));
    }

    if (!$retry && $response['code'] === 401) {
      $this->obtain_access_token();
      return $this->api_request($endpoint, $options, true);
    }
    return $response;
  }

  private function store_jwt($responseBody)
  {
    // set a transient for the duration of the jwt's expiry
    set_transient('veloappio_jwt', $responseBody['jwt'], $responseBody['expiry']);
    // save the jwt without expiry for refreshing
    add_option('veloappio_jwt', $responseBody['jwt']);
    // return the token
    return $responseBody['jwt'];
  }

  // https://docs.google.com/document/d/1SPR55i7EujNcg4e9HMBvruy0YuyWnyb9jMm41GVMIQQ/edit#heading=h.hhtqlga7mvw8
  private function obtain_access_token()
  {
    $jwt = get_transient('veloappio_jwt');
    if (!$jwt || !strlen($jwt)) {
      $jwt = get_option('veloappio_jwt');
      if ($jwt && strlen($jwt)) {
        // There's a valid, expired JWT - refresh it
        $jwt = $this->refresh_access_token($jwt);
        if (!is_wp_error($jwt)) {
          return $jwt;
        }
      }
    }
    $response = $this->parse_wp_remote_response(wp_remote_post($this->api_endpoint('login'), [
      'method' => 'POST',
      'headers' => [
        'Content-Type' => 'application/json',
        'X-Velo-Api-Key' => $this->settings['api_key'] ?? '',
      ],
      'body' => json_encode([
        'email' => $this->settings['email'] ?? '',
        'password' => $this->settings['password'] ?? '',
      ]),
    ]));

    if ($response['code'] === 200) {
      return $this->store_jwt($response['body']);
    } else {
      return $this->throw_error('401', __('invalid_credentials', 'veloappio'));
    }
  }

  private function refresh_access_token($jwt)
  {
    if (!strlen($jwt)) {
      return false;
    }
    $response = $this->parse_wp_remote_response(wp_remote_post($this->api_endpoint('refresh'), [
      'method' => 'POST',
      'headers' => [
        'Content-Type' => 'application/json',
        'X-Velo-Api-Key' => $this->settings['api_key'] ?? '',
        'X-Velo-Hmac' => hash_hmac(
          'sha256',
          get_option('veloappio_jwt') . $this->settings['api_key'] ?? '',
          $this->settings['api_secret'] ?? ''
        ),
        'Authorization' => 'Bearer ' . $jwt,
      ]
    ]));


    if ($response['code'] === 200) {
      return $this->store_jwt($response['body']);
    } else {
      // if refresh failed, try to get new access token
      return null;
    }
  }

  private function throw_error($code, $message, $data = '')
  {
    return new WP_Error($code, $message, $data);
  }

  private function get_headers()
  {
    if (
      !isset($this->settings['email']) ||
      !strlen($this->settings['email']) ||
      !isset($this->settings['password']) ||
      !strlen($this->settings['password']) ||
      !isset($this->settings['api_key']) ||
      !strlen($this->settings['api_key']) ||
      !isset($this->settings['api_secret']) ||
      !strlen($this->settings['api_secret'])
    ) {
      return $this->throw_error('422', __('missing_credentials', 'veloappio'));
    }

    $this->obtain_access_token();

    return [
      'Content-Type' => 'application/json',
      'X-Velo-Api-Key' => $this->settings['api_key'] ?? '',
      'X-Velo-Hmac' => hash_hmac(
        'sha256',
        get_transient('veloappio_jwt') . $this->settings['api_key'] ?? '',
        $this->settings['api_secret'] ?? '',
      ),
      'Authorization' => 'Bearer ' . get_transient('veloappio_jwt'),
    ];
  }

  private function get_store_address()
  {
    return [
      'line1' => get_option('woocommerce_store_address'),
      'line2' => (get_option('woocommerce_store_address_2')) ? get_option('woocommerce_store_address_2') : '',
      'city' => get_option('woocommerce_store_city'),
      'state' => (get_option('woocommerce_store_state')) ? get_option('woocommerce_store_state') : '',
      'zipcode' => (get_option('woocommerce_store_postcode')) ? get_option('woocommerce_store_postcode') : '',
      'phone' => '',
      'country' => WC()->countries->countries[WC()->countries->get_base_country()],
    ];
  }

  // https://docs.google.com/document/d/1SPR55i7EujNcg4e9HMBvruy0YuyWnyb9jMm41GVMIQQ/edit#heading=h.sjyzq9ha0gxj
  public function get_shipping_options($customerAddress, $weight, $products)
  {

    $storeAddress = $this->get_store_address();
    // validate required fields
    foreach (['line1', 'city', 'country'] as $requiredField) {
      if (!strlen($customerAddress[$requiredField])) {
        return [];
      }
    }
    // get auth headers
    $headers = $this->get_headers();
    if (is_wp_error($headers)) {
      return $headers;
    }

    $response = $this->api_request('check', [
      'method' => 'POST',
      'timeout' => 60,
      'headers' => $headers,
      'body' => json_encode([
        'customerAddress' => $customerAddress,
        'storeAddress' => $this->get_store_address(),
        'weight' => 0, //$weight
        // 'products' => $products,
        'dimensions' => [
          'width' => 0,
          'height' => 0,
          'depth' => 0,
        ],
      ]),
    ]);

    if ($response['code'] === 200) {
      return $response['body'];
    } else {
      return $this->throw_error('500', __('get_shipping_options_500', 'veloappio'));
    }
  }

  private function get_order_products($items)
  {
    $products = [];
    foreach ($items as $i => $item) {
      $product = wc_get_product((isset($item['variation_id']) && $item['variation_id']) ? $item['variation_id'] : $item['product_id']);
      $item['sku'] = $product->get_sku();
      $products[] = [
        'name' => $item['name'],
        'code' => $product->get_sku(),
        'variation' => (isset($item['variation_id']) && $item['variation_id']) ? $product->get_name() : null,
        'price' => floatVal($item['total']),
        'quantity' => $item['quantity'],
        'weight' => ($product->has_weight()) ? $product->get_weight() : 0,
      ];
    }
    return $products;
  }

    /**
     * Send an order to Velo
     *
     * This function sends the order details to the Velo API for processing.
     * It prepares the payload with customer and order information, and makes
     * an API request to create the order in the Velo system.
     *
     * @param  WC_Order $order The WooCommerce order object
     * @param  int|bool $polygonId The polygon ID for the shipping area (optional)
     * @param  int|bool $externalServiceId The external service ID (optional)
     * @param  bool $dumpPayload Whether to return the payload instead of sending (optional)
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse|array
     */
  // https://docs.google.com/document/d/1SPR55i7EujNcg4e9HMBvruy0YuyWnyb9jMm41GVMIQQ/edit#heading=h.x6ftugkbyys8
  public function send_order($order, $polygonId = false, $externalServiceId = false, $dumpPayload = false)
  {
    $payload = [
      'external_id' => 'VWC' . substr($this->settings['api_key'] ?? '', -3) . '_' . $order->get_id(),
      'weight' => 0,
      'dimensions' => [
        'width' => 0,
        'height' => 0,
        'depth' => 0,
      ],
      'note' => $order->get_customer_note(),
      'storeAddress' => $this->get_store_address(),
      'customerAddress' => [
        'first_name' => (strlen($order->get_shipping_first_name())) ? $order->get_shipping_first_name() : $order->get_billing_first_name(),
        'last_name' => (strlen($order->get_shipping_last_name())) ? $order->get_shipping_last_name() : $order->get_billing_last_name(),
        'phone' => (strlen($order->get_shipping_phone())) ? $order->get_shipping_phone() : $order->get_billing_phone(),
        'line1' => (strlen($order->get_shipping_address_1())) ? $order->get_shipping_address_1() : $order->get_billing_address_1(),
        'line2' => (strlen($order->get_shipping_address_2())) ? $order->get_shipping_address_2() : $order->get_billing_address_2(),
        'city' => (strlen($order->get_shipping_city())) ? $order->get_shipping_city() : $order->get_billing_city(),
        'state' => (strlen($order->get_shipping_state())) ? $order->get_shipping_state() : $order->get_billing_state(),
        'zipcode' => (strlen($order->get_shipping_postcode())) ? $order->get_shipping_postcode() : $order->get_billing_postcode(),
        'country' => (strlen($order->get_shipping_country())) ? WC()->countries->countries[$order->get_shipping_country()] : WC()->countries->countries[$order->get_billing_country()],
      ],
      'products' => $this->get_order_products(array_map(function ($item) {
        return $item->get_data();
      }, $order->get_items(apply_filters('woocommerce_purchase_order_item_types', 'line_item')))),
    ];

    if ($polygonId) {
      $payload['polygon_id'] = $polygonId;
    }

    if ($externalServiceId) {
      $payload['external_service_id'] = $externalServiceId;
    }

    foreach ($payload['products'] as $productData) {
      $payload['weight'] += $productData['weight'];
    }

    if ($dumpPayload) {
      return $payload;
    }

    $headers = $this->get_headers();
    if (is_wp_error($headers)) {
      return $headers;
    }

    $response = $this->api_request('order', [
      'method' => 'POST',
      'timeout' => 60,
      'headers' => $this->get_headers(),
      'body' => json_encode($payload),
    ]);

    foreach ($response['body'] as $status => $statusOrders) {
      if ($status === 'failed') {
        continue;
      }
      foreach ($statusOrders as $veloOrder) {
        if (isset($veloOrder['external_id']) === $payload['external_id']) {
          add_post_meta($order->get_id, 'veloappio_order_name', $veloOrder['name']);
        }
      }
    }
    do_action('veloappio_after_send_order', $response['body']);
    return $response['body'];
  }

  public function export_deliveries($post_ids, $returnRedirect = false)
  {
    $orders = [];
    foreach ($post_ids as $post_id) {
      $orders[] = $this->send_order(wc_get_order($post_id), false, true);
    }
    $headers = $this->get_headers();
    if (is_wp_error($headers)) {
      return $headers;
    }

    $response = $this->api_request('import', [
      'method' => 'POST',
      'headers' => $this->get_headers(),
      'body' => json_encode(['orders' => $orders]),
    ]);

    $orders = $response['body'];
    $orderNames = [];

    foreach ($orders as $status => $responseOrders) {
      if ($status === 'failed') {
        continue;
      }
      foreach ($responseOrders as $responseOrder) {
        $orderNames[$responseOrder['name']] = true;
      }
    }

    if (!count($orderNames)) {
      return json_encode([
        'success' => false,
        'message' => __('none_exported', 'veloappio'),
      ]);
    }
    $orderNames = array_keys($orderNames);
    $orderNames = implode(',', $orderNames);
    do_action('veloappio_after_export_deliveries', $orderNames);
    if ($returnRedirect) {
      return rtrim($this->server_root, '/') . '/woocommerce/import_orders/' . $this->settings['api_key'] ?? '' . '/?orders=' . $orderNames;
    }
    return json_encode([
      'success' => true,
      'message' => __('exported_succesfully', 'veloappio'),
    ]);
  }
}
